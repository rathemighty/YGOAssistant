package edu.csuci.yugiohcalc;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

import edu.csuci.yugiohcalc.databinding.ActivityCalculatorBinding;

public class Calculator extends AppCompatActivity {
    private ActivityCalculatorBinding binding;
    private double valueOne = Double.NaN;
    private double valueTwo;
    private Button buttonZero;
    private Button buttonPlus;
    private Button buttonClear;
    private Button buttonCoin;
    private Button buttonDice;
    private Button buttonDraw;
    private Button buttonEight;
    private Button buttonFive;
    private Button buttonFour;
    private Button buttonHundred;
    private Button buttonMinus;
    private Button buttonMinus2;
    private Button buttonNine;
    private Button buttonOne;
    private Button buttonPlus2;
    private Button buttonReset;
    private Button buttonSeven;
    private Button buttonSix;
    private Button buttonThousand;
    private Button buttonThree;
    private Button buttonTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_calculator);

        buttonZero = (Button)findViewById(R.id.buttonZero);
        buttonEight = (Button)findViewById(R.id.buttonEight);
        buttonFive = (Button)findViewById(R.id.buttonFive);
        buttonFour = (Button)findViewById(R.id.buttonFour);
        buttonHundred = (Button)findViewById(R.id.buttonHundred);
        buttonNine = (Button)findViewById(R.id.buttonNine);
        buttonOne = (Button)findViewById(R.id.buttonOne);
        buttonSeven = (Button)findViewById(R.id.buttonSeven);
        buttonSix = (Button)findViewById(R.id.buttonSix);
        buttonThousand = (Button)findViewById(R.id.buttonThousand);
        buttonThree = (Button)findViewById(R.id.buttonThree);
        buttonTwo = (Button)findViewById(R.id.buttonTwo);
        buttonPlus = (Button)findViewById(R.id.buttonPlus);
        buttonClear = (Button) findViewById(R.id.buttonClear);
        buttonCoin = (Button) findViewById(R.id.buttonCoin);
        buttonDice = (Button)findViewById(R.id.buttonDice);
        buttonDraw = (Button)findViewById(R.id.buttonDraw);
        buttonMinus = (Button)findViewById(R.id.buttonMinus);
        buttonMinus2 = (Button)findViewById(R.id.buttonMinus2);
        buttonPlus2 = (Button)findViewById(R.id.buttonPlus2);
        buttonReset = (Button)findViewById(R.id.buttonReset);

        buttonZero.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "0");
            }
        });

        buttonOne.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "1");
            }
        });

        buttonTwo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "2");
            }
        });

        buttonThree.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "3");
            }
        });

        buttonFour.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "4");
            }
        });

        buttonFive.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "5");
            }
        });

        buttonSix.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "6");
            }
        });

        buttonSeven.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "7");
            }
        });

        buttonEight.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "8");
            }
        });

        buttonNine.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "9");
            }
        });

        buttonHundred.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "00");
            }
        });

        buttonThousand.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                binding.editText.setText(binding.editText.getText() + "000");
            }
        });



        buttonPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valueOne = Double.parseDouble(binding.textView3.getText().toString());
                valueTwo = Double.parseDouble(binding.editText.getText().toString());
                valueOne = valueOne + valueTwo;
                binding.textView3.setText(valueOne + "");
                binding.editText.setText("0");
            }
        });

        buttonPlus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valueOne = Double.parseDouble(binding.textView5.getText().toString());
                valueTwo = Double.parseDouble(binding.editText.getText().toString());
                valueOne = valueOne + valueTwo;
                binding.textView5.setText(valueOne + "");
                binding.editText.setText("0");
            }
        });

        buttonMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valueOne = Double.parseDouble(binding.textView3.getText().toString());
                valueTwo = Double.parseDouble(binding.editText.getText().toString());
                valueOne = valueOne - valueTwo;
                binding.textView3.setText(valueOne + "");
                binding.editText.setText("0");
            }
        });

        buttonMinus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valueOne = Double.parseDouble(binding.textView5.getText().toString());
                valueTwo = Double.parseDouble(binding.editText.getText().toString());
                valueOne = valueOne - valueTwo;
                binding.textView5.setText(valueOne + "");
                binding.editText.setText("0");
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                binding.editText.setText("0");
                binding.CoinDie.setText(null);
                valueOne = Double.NaN;
            }
        });

        buttonCoin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Random rand = new Random();
                int num = rand.nextInt(2)+1;
                String result;

                if(num % 2 == 0)
                {
                    result = "HEADS";
                }
                else
                {
                    result = "TAILS";
                }
                binding.CoinDie.setText(result);
                valueOne = Double.NaN;
            }
        });

        buttonDice.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Random rand = new Random();
                int num = rand.nextInt(6)+1;

                binding.CoinDie.setText(String.valueOf(num));
                valueOne = Double.NaN;
            }
        });

        buttonDraw.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                binding.textView3.setText("DR");
                binding.textView5.setText("AW");
                binding.editText.setText(null);
            }
        });

        buttonReset.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                binding.textView3.setText("9000");
                binding.textView5.setText("9000");
            }
        });
    }
}

// androidauthority.com for much of the code